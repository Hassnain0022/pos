module.exports = { reactStrictMode: false };
